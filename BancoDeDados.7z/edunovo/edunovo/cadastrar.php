<?php
session_start();
include("conexao.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = mysqli_real_escape_string($conexao, $_POST["nome"]);
    $email = mysqli_real_escape_string($conexao, $_POST["email"]);
    $senha = mysqli_real_escape_string($conexao, $_POST["senha"]);
    $genero = mysqli_real_escape_string($conexao, $_POST["genero"]);
    $data_de_nascimento = mysqli_real_escape_string($conexao, $_POST["data_de_nascimento"]);

    // Verificar se o email já está cadastrado
    $sql_check = "SELECT * FROM novos WHERE email = '$email'";
    $resultado_check = mysqli_query($conexao, $sql_check);

    if (mysqli_num_rows($resultado_check) > 0) {
        echo "Esse email já está cadastrado.";
    } else {
        // Criptografar a senha antes de salvar
        $senha_criptografada = password_hash($senha, PASSWORD_DEFAULT);

        // Inserir dados no banco
        $sql = "INSERT INTO novos (nome, email, senha, genero, data_de_nascimento)
                VALUES ('$nome', '$email', '$senha_criptografada', '$genero', '$data_de_nascimento')";

        if (mysqli_query($conexao, $sql)) {
            echo "Usuário cadastrado com sucesso!";
            header("Location: login.html");
            exit();
        } else {
            echo "Erro ao cadastrar: " . mysqli_error($conexao);
        }
    }
    mysqli_close($conexao);
}
?>

