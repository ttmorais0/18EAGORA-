<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id']))



$genero = $_SESSION['u_genero'];

if ($genero == "homem") {
    $css = "meninos.css";
}

elseif ($genero == "menina") {
    $css = "meninas.css";
}
?>
<?php if (isset($css)): ?>
        <link rel="stylesheet" href="<?php echo $css; ?>">
    <?php endif; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página do Cliente</title>
</head>
<body>
    <h1>Bem-vindo à sua página, <?php echo htmlspecialchars($_SESSION['u_nome']); ?>!</h1>
    <p>Esta é a sua área de cliente, onde você pode acessar seus dados e funcionalidades exclusivas.</p>
    <p><?php echo htmlspecialchars($_SESSION['u_data_de_nascimento']); ?>!</p>
    <p><?php echo htmlspecialchars($_SESSION['u_genero']); ?>!</p>

   

    
    
    <a href="logout.php">Sair</a>

</body>
</html>
