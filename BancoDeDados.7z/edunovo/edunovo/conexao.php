<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$dbname = "teste";

$conexao = mysqli_connect($servidor, $usuario, $senha, $dbname);
if (!$conexao) {
    die("Erro de conexão: " . mysqli_connect_error());
}
?>

