-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 24/10/2024 às 02:37
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `teste`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `novos`
--

CREATE TABLE novos (
    
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE PRIMARY KEY,
    senha VARCHAR(255) NOT NULL,
    genero VARCHAR(10),
    data_de_nascimento DATE
);
  ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `novos`
--

INSERT INTO `novos` (`nome`, `email`, `senha`, `genero`, `data_de_nascimento`) VALUES
('Ana', 'ana@gmail.com', 'ana123', 'menina', '2011-11-21'),
('Eduardo', 'oeduardocoutocontato@gmail.com', 'Edulindo', 'homem', '0000-00-00');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `novos`
--
ALTER TABLE `novos`
  ADD PRIMARY KEY (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
