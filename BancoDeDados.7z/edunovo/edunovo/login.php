<?php


session_start();
include("conexao.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conexao, $_POST['email']);
    $senha = mysqli_real_escape_string($conexao, $_POST['senha']);

    // Verificar se o usuário existe no banco
    $sql = "SELECT * FROM novos WHERE email = '$email'";
    $result = mysqli_query($conexao, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        // Verificar se a senha está correta
        if (password_verify($senha, $row['senha'])) {
            // Senha correta, salvar dados do usuário na sessão
            $_SESSION['usuario_id'] = $row['id'];
            $_SESSION['u_nome'] = $row['nome'];
            $_SESSION['u_data_de_nascimento'] = $row['data_de_nascimento'];
            $_SESSION['u_genero'] = $row['genero'];

            // Redirecionar para a página do cliente
            header("Location: cliente.php");
            exit(); // Use exit após o redirecionamento
        } else {
            echo "Senha incorreta!";
        }
    } else {
        echo "Usuário não encontrado!";
    }
}


mysqli_close($conexao);
?>

